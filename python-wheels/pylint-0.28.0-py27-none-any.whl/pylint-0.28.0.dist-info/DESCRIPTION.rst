README for Pylint (http://www.pylint.org)
=========================================

Pylint is a Python source code analyzer which looks for programming errors,
helps enforcing a coding standard and sniffs for some code smells (as defined in
Martin Fowler's Refactoring book).

Pylint has many rules enabled by default, way too much to silent them all on a
minimally sized program. It's highly configurable and handle pragmas to control
it from within your code. Additionally, it is possible to write plugins to add
your own checks.

It's a free software distributed under the GNU Public Licence.

Development is hosted on bitbucket: https://bitbucket.org/logilab/pylint/ .

You can use the python-projects@logilab.org mailing list to discuss about
Pylint. Subscribe at http://lists.logilab.org/mailman/listinfo/python-projects
or read the archives at http://lists.logilab.org/pipermail/python-projects/


Install
-------

Pylint requires the astng (the later the better) and logilab-common (version >=
0.53) packages.

*  https://bitbucket.org/logilab/astng
* http://www.logilab.org/projects/common

>From the source distribution, extract the tarball and run ::

    python setup.py install

You'll have to install dependencies in a similar way. For debian and
rpm packages, use your usual tools according to your Linux distribution.

More information about installation and available distribution format
may be found in the user manual in the *doc* subdirectory.


Documentation
-------------

Look in the doc/ subdirectory or at http://docs.pylint.org

Pylint is shipped with following additional commands:

* pyreverse: an UML diagram generator
* symilar: an independent similarities checker
* epylint: Emacs and Flymake compatible Pylint
* pylint-gui: a graphical interface


Contributors
------------

order doesn't matter...

* Sylvain Thenault: main author / maintainer
* Alexandre Fayolle: TkInter gui, documentation, debian support
* Emile Anclin: used to maintain, py3k support
* Mads Kiilerich: various patches
* Torsten Marek, various patches
* Boris Feld, various patches
* Brian van den Broek: windows installation documentation
* Amaury Forgeot d'Arc: patch to check names imported from a module
  exists in the module
* Benjamin Niemann: patch to allow block level enabling/disabling of messages
* Nathaniel Manista: suspicious lambda checking
* Wolfgang Grafen, Axel Muller, Fabio Zadrozny, Pierre Rouleau,
  Maarten ter Huurne, Mirko Friedenhagen (among others):
  bug reports, feedback, feature requests...
* Martin Pool (Google): warnings for anomalous backslashes, symbolic names
  for messages (like 'unused')
* All the Logilab's team: daily use, bug reports, feature requests
* Other people have contributed by their feedback, if I've forgotten
  you, send me a note !


